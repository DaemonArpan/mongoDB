//to find smartphones priced at $800 with weight less than 200 grams
db.techProducts.find({
  "type": "smartphone",
  "price": 800,
  "shipping.weight_gram": { $lt: 200 }
}).pretty()

{
  _id: ObjectId('68e3b2276cc04f13e81f1c89'),
  productId: 'SANDESHSP-2',
  type: 'smartphone',
  brand: 'Apple',
  model: 'iPhone 17',
  price: 800,
  specifications: {
    camera: {
      rear: [
        {
          megapixels: 48,
          aperture: 'f/1.6',
          type: 'main'
        }
      ],
      front: {
        megapixels: 12,
        aperture: 'f/1.9'
      }
    },
    battery: {
      capacity: 3349,
      unit: 'mAh'
    },
    operatingSystem: {
      name: 'iOS',
      version: '17'
    }
  },
  shipping: {
    dimensions: {
      width: 71.6,
      height: 147.6,
      depth: 7.8
    },
    weight_gram: 171
  },
  releaseDate: 2025-09-22T00:00:00.000Z,
  availability: true
}