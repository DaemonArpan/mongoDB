// to find laptops with shipping weight greater than 200 grams
db.techProducts.find({ "shipping.weight_gram": { $gt: 200 } }).pretty()
{
  _id: ObjectId('68e3b2276cc04f13e81f1c86'),
  productId: 'SANDESHLP-01',
  type: 'laptop',
  brand: 'Dell',
  model: 'ALIENWARE',
  price: 1299.99,
  specifications: {
    processor: {
      brand: 'Intel',
      model: 'Core i7-1165G7',
      cores: 4,
      baseSpeed: '2.8GHz'
    },
    memory: {
      RAM: '16GB',
      type: 'LPDDR5x'
    },
    storage: {
      capacity: '512GB',
      type: 'NVMe SSD'
    },
    graphics: {
      type: 'integrated',
      model: 'GTX 4050'
    }
  },
  shipping: {
    dimensions: {
      width: 296,
      height: 14.8,
      depth: 199
    },
    weight_gram: 1200
  },
  releaseDate: 2025-03-15T00:00:00.000Z,
  availability: true
}
{
  _id: ObjectId('68e3b2276cc04f13e81f1c87'),
  productId: 'SANDESHLP-2',
  type: 'laptop',
  brand: 'Apple',
  model: 'MacBook Air M2',
  price: 1199.99,
  specifications: {
    processor: {
      brand: 'Apple',
      model: 'M4',
      cores: 8
    },
    memory: {
      RAM: '8GB',
      type: 'Unified Memory'
    },
    storage: {
      capacity: '256GB',
      type: 'SSD'
    },
    graphics: {
      type: 'integrated',
      model: '8-core GPU'
    }
  },
  shipping: {
    dimensions: {
      width: 304.1,
      height: 11.3,
      depth: 215
    },
    weight_gram: 1240
  },
  releaseDate: 2025-07-15T00:00:00.000Z,
  availability: true
}