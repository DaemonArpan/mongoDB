use TechLibrary
switched to db TechLibrary
// Collection Creation with Validation Schema
db.createCollection("techProducts", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["productId", "type", "brand", "model", "price"],
      properties: {
        productId: {
          bsonType: "string",
          description: "Product ID must be a string"
        },
        type: {
          enum: ["laptop", "smartphone", "tablet", "smartwatch"],
          description: "Product type must be one of the specified values"
        },
        price: {
          bsonType: ["double", "int"],
          minimum: 0,
          description: "Price must be a positive number"
        },
        availability: {
          bsonType: "bool",
          description: "Availability must be boolean"
        }
      }
    }
  }
})
