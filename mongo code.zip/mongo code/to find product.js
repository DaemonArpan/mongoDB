db.techProducts.find().pretty()
// code to find products 
_id: ObjectId('68e3b2276cc04f13e81f1c86'),
  productId: 'SANDESHLP-01',
  type: 'laptop',
  brand: 'Dell',
  model: 'ALIENWARE',
  price: 1299.99,
  specifications: {
    processor: {
      brand: 'Intel',
      model: 'Core i7-1165G7',
      cores: 4,
      baseSpeed: '2.8GHz'
    },
    memory: {
      RAM: '16GB',
      type: 'LPDDR5x'
    },
    storage: {
      capacity: '512GB',
      type: 'NVMe SSD'
    },
    graphics: {
      type: 'integrated',
      model: 'GTX 4050'
    }
  },
  shipping: {
    dimensions: {
      width: 296,
      height: 14.8,
      depth: 199
    },
    weight_gram: 1200
  },
  releaseDate: 2025-03-15T00:00:00.000Z,
  availability: true
}
{
  _id: ObjectId('68e3b2276cc04f13e81f1c87'),
  productId: 'SANDESHLP-2',
  type: 'laptop',
  brand: 'Apple',
  model: 'MacBook Air M2',
  price: 1199.99,
  specifications: {
    processor: {
      brand: 'Apple',
      model: 'M4',
      cores: 8
    },
    memory: {
      RAM: '8GB',
      type: 'Unified Memory'
    },
    storage: {
      capacity: '256GB',
      type: 'SSD'
    },
    graphics: {
      type: 'integrated',
      model: '8-core GPU'
    }
  },
  shipping: {
    dimensions: {
      width: 304.1,
      height: 11.3,
      depth: 215
    },
    weight_gram: 1240
  },
  releaseDate: 2025-07-15T00:00:00.000Z,
  availability: true
}
{
  _id: ObjectId('68e3b2276cc04f13e81f1c88'),
  productId: 'SANDESHSP-1',
  type: 'smartphone',
  brand: 'Samsung',
  model: 'Galaxy S25',
  price: 750,
  specifications: {
    camera: {
      rear: [
        {
          megapixels: 50,
          aperture: 'f/1.8',
          type: 'main'
        }
      ],
      front: {
        megapixels: 12,
        aperture: 'f/2.2'
      }
    },
    battery: {
      capacity: 4000,
      unit: 'mAh'
    },
    operatingSystem: {
      name: 'Android',
      version: '14'
    }
  },
  shipping: {
    dimensions: {
      width: 70.6,
      height: 147,
      depth: 7.6
    },
    weight_gram: 167
  },
  releaseDate: 2025-01-24T00:00:00.000Z,
  availability: true
}
{
  _id: ObjectId('68e3b2276cc04f13e81f1c89'),
  productId: 'SANDESHSP-2',
  type: 'smartphone',
  brand: 'Apple',
  model: 'iPhone 17',
  price: 800,
  specifications: {
    camera: {
      rear: [
        {
          megapixels: 48,
          aperture: 'f/1.6',
          type: 'main'
        }
      ],
      front: {
        megapixels: 12,
        aperture: 'f/1.9'
      }
    },
    battery: {
      capacity: 3349,
      unit: 'mAh'
    },
    operatingSystem: {
      name: 'iOS',
      version: '17'
    }
  },
  shipping: {
    dimensions: {
      width: 71.6,
      height: 147.6,
      depth: 7.8
    },
    weight_gram: 171
  },
  releaseDate: 2025-09-22T00:00:00.000Z,
  availability: true
}