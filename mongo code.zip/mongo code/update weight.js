// Update Weight of Dell ALIENWARE
db.techProducts.updateOne(
  { "productId": "SANDESHLP-01" },
  { 
    $set: { 
      "shipping.weight_gram": 1250,
      "updatedAt": new Date()
    }
  }
)
{
  acknowledged: true,
  insertedId: null,
  matchedCount: 1,
  modifiedCount: 1,
  upsertedCount: 0
}
// to know is update was sucessfull
db.techProducts.findOne(
  {"productId": "SANDESHLP-01"}, 
  {"shipping.weight_gram": 1, "productId": 1}
)
{
  _id: ObjectId('68e3b2276cc04f13e81f1c86'),
  productId: 'SANDESHLP-01',
  shipping: {
    weight_gram: 1250
  }
}