// Primary Indexes for Common Queries
db.techProducts.createIndex({ "brand": 1, "type": 1 })
db.techProducts.createIndex({ "price": 1 })
db.techProducts.createIndex({ "shipping.weight_gram": 1 })
db.techProducts.createIndex({ "specifications.operatingSystem.name": 1 })
db.techProducts.createIndex({ "model": 1 })
db.techProducts.createIndex({ "specifications.processor.brand": 1 })

// Compound Index for Complex Queries
db.techProducts.createIndex({ 
  "type": 1, 
  "price": 1, 
  "shipping.weight_gram": 1 
})

// Text Index for Product Search
db.techProducts.createIndex({
  "brand": "text",
  "model": "text",
  "specifications.processor.model": "text"
})