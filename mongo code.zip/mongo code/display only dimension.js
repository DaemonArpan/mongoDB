// to find all laptops and return only shipping dimensions
db.techProducts.find(
  { "type": "laptop" },
  { 
    "_id": 0,
    "brand": 1,
    "model": 1,
    "shipping.dimensions": 1
  }
).pretty()
{
  brand: 'Apple',
  model: 'MacBook Air M2',
  shipping: {
    dimensions: {
      width: 304.1,
      height: 11.3,
      depth: 215
    }
  }
}
{
  brand: 'Dell',
  model: 'ALIENWARE',
  shipping: {
    dimensions: {
      width: 296,
      height: 14.8,
      depth: 199
    }
  }
}