// to drop  Price Index
db.techProducts.dropIndex({ "price": 1 })

{ nIndexesWas: 9, ok: 1 }