// Performance Analysis 

db.techProducts.find({ "brand": "Samsung" }).explain("executionStats")